﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        private bool HayUsuarioEnSession()
        {
            string valor = HttpContext.Session.GetString("user");
            if (string.IsNullOrEmpty(valor))
            {
                return false;
            }
            return true;
        }

        public IActionResult Index()
        {

            if (!HayUsuarioEnSession())
            {
                return RedirectToAction("Index", "Login");
            }
            return View();
        }

        public IActionResult Logout()
        {
            return RedirectToAction("Logout", "Login");
        }


        
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}