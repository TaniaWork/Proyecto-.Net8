﻿using Domain.Exceptions;
using dto;
using Microsoft.AspNetCore.Mvc;
using Services;

namespace WebApplication1.Controllers
{
    public class LoginController : Controller
    {
        private IServiceLogin<LoginDto, LoginOutDto> _service;
        public LoginController(IServiceLogin<LoginDto, LoginOutDto> service)
        {
            _service = service;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {            
            return View();
        }

        [HttpGet]
        public IActionResult Loginfail()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("user");
            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public IActionResult Login(LoginDto loginDto)
        {

            try
            {
                LoginOutDto loginOutDto = _service.Login(loginDto);
                HttpContext.Session.SetString("user", loginOutDto.nombre);
                HttpContext.Session.SetString("token", loginOutDto.token);
            }
            catch (LoginException loginException)
            {
                return RedirectToAction("Loginfail");
            }
            return RedirectToAction("Index", "Home");
        }


       

    }
}
