﻿using dto;
using Microsoft.AspNetCore.Mvc;
using Services;
using System.Diagnostics;
using WebApplication1.Models;




namespace WebApplication1.Controllers
{
    
    
    public class TipoController : Controller
    {
        
        private static readonly int RECORDS_PER_PAGE = 5;
        private IServiceTipo _service;
        public TipoController(IServiceTipo service)
        {
            _service = service;
        }

        private bool HayUsuarioEnSession()
        {
            string valor = HttpContext.Session.GetString("user");
            if (string.IsNullOrEmpty(valor))
            {
                return false;
            }
            return true;
        }

        public IActionResult Index(string name, int skip, int take)
        {
            
            if (!HayUsuarioEnSession())
            {
                return RedirectToAction("Index", "Login");
            }

            String nameFilter = "" + name;
            if (take == 0)
            {
                take = RECORDS_PER_PAGE;
            }

            TipoResponseDto tipoResponseDto = _service.GetByName(nameFilter, skip, take);
            
            ViewBag.skip = skip;
            ViewBag.take = take;
            ViewBag.Count = tipoResponseDto.Count;
            ViewBag.tipoResponseDto = tipoResponseDto;
            ViewBag.paginaActual = (skip / take) + 1;
            ViewBag.totalDePaginas = (int)Math.Ceiling((decimal)tipoResponseDto.Count / take);
            return View();
        }

        [HttpGet]
        public IActionResult Create()
        {            
            return View();
        }

        [HttpGet]
        public IActionResult Display(int id)
        {
            Tipo tipo = _service.GetById(id);
            return View(tipo);
            
        }

        [HttpPost]
        public IActionResult Display(Tipo tipo)
        {
            return RedirectToAction("Index");
        }


        [HttpGet]
        public IActionResult Update(int id)
        {
            Tipo tipo = _service.GetById(id);
            return View(tipo);
        }

        [HttpPost]
        public IActionResult Create(Tipo tipo)
        {            
            _service.Add(tipo);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Update(Tipo tipo)
        {
            _service.Update(tipo.Id, tipo);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult FilterByName(string name, int skip, int take)
        {         
            return RedirectToAction("Index", new { name = name, skip = skip, take = take});
        }

        [HttpGet]
        public IActionResult PageBack(string name, int skip, int take)
        {
            int newSkip = _calculateBackPageSkip(skip, take);
            return RedirectToAction("Index", new { name = name, skip = newSkip, take = take});
        }

        private int _calculateBackPageSkip(int skip, int take)
        {
            int newSkip = skip - take;
            if (newSkip < 0)
            {
                newSkip = 0;
            }

            return newSkip;
        }
        private int _calculateNextPageSkip(int skip, int take)
        {
            int newSkip = skip + take;
            return newSkip;
        }

        [HttpGet]
        public IActionResult PageNext(string name, int skip, int take)
        {         
            int newSkip = _calculateNextPageSkip(skip, take);
            return RedirectToAction("Index", new { name = name, skip = newSkip, take = take});
        }
        
        
        [HttpGet]
        public IActionResult Remove(int id)
        {

            Tipo tipoDto = _service.GetById(id);
            return View(tipoDto);
        }

        [HttpPost]
        public IActionResult Remove(Tipo tipo)
        {
            _service.Remove(tipo.Id);
            return RedirectToAction("Index");
        }

 
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
