﻿using dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services;
using System.Diagnostics;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class MovimientoController : Controller
    {

        private IServiceMovimiento _serviceMovimiento;

        public IWebHostEnvironment _webHostEnvironment { get; set; }

        public IConfiguration _configuration;
        public MovimientoController(IConfiguration configuration,
                                IServiceMovimiento serviceMovimiento,
                                IWebHostEnvironment webHostEnvironment)
        {
            this._serviceMovimiento = serviceMovimiento;
            this._webHostEnvironment = webHostEnvironment;
            this._configuration = configuration;
        }

        private bool HayUsuarioEnSession()
        {
            string valor = HttpContext.Session.GetString("user");
            if (string.IsNullOrEmpty(valor))
            {
                return false;
            }
            return true;
        }

        public IActionResult Index(string name)
        {


            if (!HayUsuarioEnSession())
            {
                return RedirectToAction("Index", "Login");
            }
            string nameFilter = "" + name;
            IEnumerable<Movimiento> movimientos = _serviceMovimiento.GetByName(nameFilter);
            ViewBag.Movimiento = movimientos;
            return View();
        }




        [HttpGet]
        public IActionResult Create()
        {

            return View(GetViewModelMovimiento());
        }

        private ViewModelMovimiento GetViewModelMovimiento()
        {
            ViewModelMovimiento viewModelMovimiento = new ViewModelMovimiento();
            return viewModelMovimiento;
        }

        [HttpGet]
        public IActionResult Display(int id)
        {
            Movimiento movimientos = this._serviceMovimiento.GetById(id);
            ViewModelMovimiento viewModelMovimientos = new ViewModelMovimiento(movimientos);
            return View(viewModelMovimientos);
        }


        [HttpGet]
        public IActionResult Remove(int id)
        {
            Movimiento movimientos = this._serviceMovimiento.GetById(id);
            ViewModelMovimiento viewModelMovimiento = new ViewModelMovimiento(movimientos);
            return View(viewModelMovimiento);
        }

        [HttpPost]
        public IActionResult Remove(int id, ViewModelMovimiento viewModelMovimiento)
        {
            this._serviceMovimiento.Remove(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            Movimiento movimiento = _serviceMovimiento.GetById(id);
            ViewModelMovimiento viewModelMovimiento = new ViewModelMovimiento(movimiento);
            return View(viewModelMovimiento);
        }

        [HttpPost]
        public IActionResult Update(int id, ViewModelMovimiento viewModelMovimiento)
        {
            Movimiento movimientoDTO = viewModelMovimiento.ToMovimientoDto();
            this._serviceMovimiento.Update(id, movimientoDTO);
            return RedirectToAction("Index");
        }



        [HttpPost]
        public IActionResult Create(ViewModelMovimiento viewModelMovimiento)
        {
            Movimiento movimiento = viewModelMovimiento.ToMovimientoDto();
            _serviceMovimiento.Add(movimiento);
            return RedirectToAction("Index");

        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }





    }
}