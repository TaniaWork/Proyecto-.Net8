﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication1.Models;
using dto;
using Services;

namespace WebApplication1.Controllers
{
    public class UsuarioController : Controller
    {

        private IServiceUsuario _serviceUsuario;

        public IWebHostEnvironment _webHostEnvironment { get; set; }

        public IConfiguration _configuration;
        public UsuarioController(IConfiguration configuration,
                                IServiceUsuario serviceUsuario,
                                IWebHostEnvironment webHostEnvironment)
        {
            this._serviceUsuario = serviceUsuario;
            this._webHostEnvironment = webHostEnvironment;
            this._configuration = configuration;
        }

        private bool HayUsuarioEnSession()
        {
            string valor = HttpContext.Session.GetString("user");
            if (string.IsNullOrEmpty(valor))
            {
                return false;
            }
            return true;
        }

        public IActionResult Index(string name)
        {


            if (!HayUsuarioEnSession())
            {
                return RedirectToAction("Index", "Login");
            }
            string nameFilter = "" + name;
            IEnumerable<Usuario> usuarios = _serviceUsuario.GetByEmail(nameFilter);
            ViewBag.Usuario = usuarios;
            return View();
        }

      


        [HttpGet]
        public IActionResult Create()
        {

            return View(GetViewModelUsuario());
        }

        private ViewModelUsuario GetViewModelUsuario()
        {
            ViewModelUsuario viewModelUsuario = new ViewModelUsuario();
            return viewModelUsuario;
        }

        [HttpGet]
        public IActionResult Display(int id)
        {
            Usuario usuarios = this._serviceUsuario.GetById(id);
            ViewModelUsuario viewModelUsuario = new ViewModelUsuario(usuarios);
            return View(viewModelUsuario);
        }


        [HttpGet]
        public IActionResult Remove(int id)
        {
            Usuario usuarios = this._serviceUsuario.GetById(id);
            ViewModelUsuario viewModelUsuario = new ViewModelUsuario(usuarios);
            return View(viewModelUsuario);
        }

        [HttpPost]
        public IActionResult Remove(int id, ViewModelUsuario viewModelUsuario)
        {
            this._serviceUsuario.Remove(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            Usuario usuarios = _serviceUsuario.GetById(id);
            ViewModelUsuario viewModelUsuario = new ViewModelUsuario(usuarios);
            return View(viewModelUsuario);
        }

        [HttpPost]
        public IActionResult Update(int id, ViewModelUsuario viewModelUsuario)
        {
            Usuario usuarioDTO = viewModelUsuario.ToUsuarioDto();
            this._serviceUsuario.Update(id, usuarioDTO);
            return RedirectToAction("Index");
        }



        [HttpPost]
        public IActionResult Create(ViewModelUsuario viewModelUsuario)
        {
            Usuario usuarios = viewModelUsuario.ToUsuarioDto();
            _serviceUsuario.Add(usuarios);
            return RedirectToAction("Index");

        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }





    }
}