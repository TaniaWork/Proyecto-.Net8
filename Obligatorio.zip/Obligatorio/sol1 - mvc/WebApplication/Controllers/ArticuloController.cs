﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication1.Models;
using dto;
using Services;

namespace WebApplication1.Controllers
{
    public class ArticuloController : Controller
    {

        private IServiceArticulo _serviceArticulo;

        public IWebHostEnvironment _webHostEnvironment { get; set; }

        public IConfiguration _configuration;
        public ArticuloController(IConfiguration configuration,
                                IServiceArticulo serviceArticulo,
                                IWebHostEnvironment webHostEnvironment)
        {
            this._serviceArticulo = serviceArticulo;
            this._webHostEnvironment = webHostEnvironment;
            this._configuration = configuration;
        }

        private bool HayUsuarioEnSession()
        {
            string valor = HttpContext.Session.GetString("user");
            if (string.IsNullOrEmpty(valor))
            {
                return false;
            }
            return true;
        }

        public IActionResult Index(string name)
        {


            if (!HayUsuarioEnSession())
            {
                return RedirectToAction("Index", "Login");
            }
            string nameFilter = "" + name;
            IEnumerable<Articulo> articulos = _serviceArticulo.GetByName(nameFilter);
            ViewBag.Articulo = articulos;
            return View();
        }

      


        [HttpGet]
        public IActionResult Create()
        {

            return View(GetViewModelArticulo());
        }

        private ViewModelArticulo GetViewModelArticulo()
        {
            ViewModelArticulo viewModelArticulo = new ViewModelArticulo();
            return viewModelArticulo;
        }

        [HttpGet]
        public IActionResult Display(int id)
        {
            Articulo articulos = this._serviceArticulo.GetById(id);
            ViewModelArticulo viewModelArticulo = new ViewModelArticulo(articulos);
            return View(viewModelArticulo);
        }


        [HttpGet]
        public IActionResult Remove(int id)
        {
            Articulo articulos = this._serviceArticulo.GetById(id);
            ViewModelArticulo viewModelArticulo = new ViewModelArticulo(articulos);
            return View(viewModelArticulo);
        }

        [HttpPost]
        public IActionResult Remove(int id, ViewModelArticulo viewModelArticulo)
        {
            this._serviceArticulo.Remove(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            Articulo articulo = _serviceArticulo.GetById(id);
            ViewModelArticulo viewModelArticulo = new ViewModelArticulo(articulo);
            return View(viewModelArticulo);
        }

        [HttpPost]
        public IActionResult Update(int id, ViewModelArticulo viewModelArticulo)
        {
            Articulo articuloDTO = viewModelArticulo.ToArticuloDto();
            this._serviceArticulo.Update(id, articuloDTO);
            return RedirectToAction("Index");
        }



        [HttpPost]
        public IActionResult Create(ViewModelArticulo viewModelArticulo)
        {
            Articulo articulo = viewModelArticulo.ToArticuloDto();
            _serviceArticulo.Add(articulo);
            return RedirectToAction("Index");

        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }





    }
}