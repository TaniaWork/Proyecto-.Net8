﻿
namespace Services
{
    public interface IServiceLogin<I, O>
    {
        O Login(I dto);

    }
}
