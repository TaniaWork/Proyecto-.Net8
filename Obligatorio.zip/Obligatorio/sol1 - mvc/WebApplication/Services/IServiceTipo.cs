﻿using dto;

namespace Services
{
    public interface IServiceTipo
    {
        Tipo Add(Tipo tipo);
        void Update(int id, Tipo tipo);
        void Remove(int id);
        Tipo GetById(int id);
        TipoResponseDto GetByName(string name, int skip, int take);

    }
}
