using HttpAccess;
using dto;

namespace Services
{
    public class ServiceUsuario : IServiceUsuario
    {

        private IContextHttpUsuario _repository;


        public ServiceUsuario(IContextHttpUsuario repository)
        {
            _repository = repository;

        }

        public Usuario Add(Usuario usuario)
        {
            usuario.IsValid();
            Usuario newUsuario = _repository.Add(usuario).GetAwaiter().GetResult();
            return newUsuario;
        }



        public Usuario GetById(int id)
        {
            Usuario u = _repository.GetById(id).GetAwaiter().GetResult();
            return u;
        }


        public IEnumerable<Usuario> GetByEmail(string name)
        {
            String filters = "?"; //eje para un filtro ?variable=valor , para 2 filtros ?variable=valor&variable2=valor2
            filters += "name=" + name;
            IEnumerable<Usuario> usuario = _repository.GetAll(filters).GetAwaiter().GetResult();
            return usuario;
        }


        public void Remove(int id)
        {
            _repository.Remove(id).GetAwaiter().GetResult();

        }


        public void Update(int id, Usuario usuario)
        {
            _repository.Update(id, usuario).GetAwaiter().GetResult();

        }


    }
}


