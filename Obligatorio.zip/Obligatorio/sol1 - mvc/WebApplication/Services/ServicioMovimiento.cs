
using HttpAccess;
using dto;

namespace Services
{
    public class ServiceMovimiento : IServiceMovimiento
    {

        private IContextHttpMovimiento _repository;


        public ServiceMovimiento(IContextHttpMovimiento repository)
        {
            _repository = repository;

        }

        public Movimiento Add(Movimiento movimiento)
        {
            movimiento.IsValid();
            Movimiento newMovimiento = _repository.Add(movimiento).GetAwaiter().GetResult();
            return newMovimiento;
        }



        public Movimiento GetById(int id)
        {
            Movimiento m = _repository.GetById(id).GetAwaiter().GetResult();
            return m;
        }


        public IEnumerable<Movimiento> GetByName(string name)
        {
            String filters = "?"; //eje para un filtro ?variable=valor , para 2 filtros ?variable=valor&variable2=valor2
            filters += "name=" + name;
            IEnumerable<Movimiento> movimientos = _repository.GetAll(filters).GetAwaiter().GetResult();
            return movimientos;
        }


        public void Remove(int id)
        {
            _repository.Remove(id).GetAwaiter().GetResult();

        }


        public void Update(int id, Movimiento movimiento)
        {
            _repository.Update(id, movimiento).GetAwaiter().GetResult();

        }


    }
}

