
using HttpAccess;
using dto;

namespace Services
{
    public class ServiceArticulo : IServiceArticulo
    {

        private IContextHttpArticulo _repository;


        public ServiceArticulo(IContextHttpArticulo repository)
        {
            _repository = repository;

        }

        public Articulo Add(Articulo articulo)
        {
            articulo.IsValid();
            Articulo newArticulo = _repository.Add(articulo).GetAwaiter().GetResult();
            return newArticulo;
        }



        public Articulo GetById(int id)
        {
            Articulo a = _repository.GetById(id).GetAwaiter().GetResult();
            return a;
        }


        public IEnumerable<Articulo> GetByName(string name)
        {
            String filters = "?"; //eje para un filtro ?variable=valor , para 2 filtros ?variable=valor&variable2=valor2
            filters += "name=" + name;
            IEnumerable<Articulo> articulos = _repository.GetAll(filters).GetAwaiter().GetResult();
            return articulos;
        }


        public void Remove(int id)
        {
            _repository.Remove(id).GetAwaiter().GetResult();

        }


        public void Update(int id, Articulo articulo)
        {
            _repository.Update(id, articulo).GetAwaiter().GetResult();

        }


    }
}

