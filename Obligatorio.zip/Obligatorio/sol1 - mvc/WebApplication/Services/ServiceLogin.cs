﻿
using HttpAccess;
using dto;

namespace Services
{
    public class ServiceLogin : IServiceLogin<LoginDto, LoginOutDto>
    {

        private IContextHttpLogin _repository;
        public ServiceLogin(IContextHttpLogin repository) 
        {
            _repository = repository;
        }

        public LoginOutDto Login(LoginDto loginDto)
        {
            LoginOutDto usuario = _repository.Login(loginDto).GetAwaiter().GetResult();
            //grabo token
            return usuario;
        }
    }


}
