


using dto;

namespace Services
{
    public interface IServiceArticulo
    {
        Articulo Add(Articulo model);
        void Update(int id, Articulo model);
        void Remove(int id);
        Articulo GetById(int id);
        IEnumerable<Articulo> GetByName(string name);
    }
}
