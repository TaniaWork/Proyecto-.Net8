﻿using HttpAccess;
using Domain.Exceptions;
using dto;

namespace Services
{
    public class ServiceTipo : IServiceTipo
    {

        private IContextHttpTipo _repository;

        public ServiceTipo(IContextHttpTipo repository) 
        {
            _repository = repository;
        }
        public Tipo Add(Tipo tipo)
        {
            Tipo tipoToCreate = new Tipo();
            tipoToCreate.Nombre = tipo.Nombre;
            Tipo newTipo = _repository.Add(tipoToCreate).GetAwaiter().GetResult();
            return newTipo;
        }

        public Tipo GetById(int id)
        {
            Tipo tipo = _repository.GetById(id).GetAwaiter().GetResult();
            if (tipo == null) 
            {
                throw new NoExisteElementoException("No existe el tipo");
            }
            return tipo;
        }

        public TipoResponseDto GetByName(string name, int skip, int take)
        {
            String filters = "?"; //eje para un filtro ?variable=valor , para 2 filtros ?variable=valor&variable2=valor2
           
            filters += "name=" + name;
            filters += "&skip=" + skip;
            filters += "&take=" + take;
            TipoResponseDto tipoResponse = _repository.GetAll(filters).GetAwaiter().GetResult();
            return tipoResponse;
        }


        public void Remove(int id)
        {
            _repository.Remove(id).GetAwaiter().GetResult();
        }

        
        public void Update(int id, Tipo tipo)
        {
            _repository.Update(id, tipo).GetAwaiter().GetResult();
        }
    }


}
