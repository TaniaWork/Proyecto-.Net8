


using dto;

namespace Services
{
    public interface IServiceMovimiento
    {
        Movimiento Add(Movimiento model);
        void Update(int id, Movimiento model);
        void Remove(int id);
        Movimiento GetById(int id);
        IEnumerable<Movimiento> GetByName(string name);
    }
}
