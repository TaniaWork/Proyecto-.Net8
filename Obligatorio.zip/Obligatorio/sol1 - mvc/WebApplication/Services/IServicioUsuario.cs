
using dto;

namespace Services
{
    public interface IServiceUsuario
    {
        Usuario Add(Usuario model);
        void Update(int id, Usuario model);
        void Remove(int id);
        Usuario GetById(int id);
        IEnumerable<Usuario> GetByEmail(string email);
    }
}
