﻿
using dto;

namespace HttpAccess
{
    public interface IContextHttpArticulo: IContextHttp<Articulo>
    {
        Task<IEnumerable<Articulo>> GetAll(string filters);
        
    }
}
