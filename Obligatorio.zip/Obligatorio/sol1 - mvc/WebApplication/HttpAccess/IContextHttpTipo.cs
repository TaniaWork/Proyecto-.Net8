﻿using dto;

namespace HttpAccess
{
    public interface IContextHttpTipo: IContextHttp<Tipo>
    {
        Task<TipoResponseDto> GetAll(string filters);

    }
}
