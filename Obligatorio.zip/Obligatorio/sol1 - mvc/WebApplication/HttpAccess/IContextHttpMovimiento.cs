﻿
using dto;

namespace HttpAccess
{
    public interface IContextHttpMovimiento: IContextHttp<Movimiento>
    {
        Task<IEnumerable<Movimiento>> GetAll(string filters);
        
    }
}
