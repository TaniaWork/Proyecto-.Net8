using dto;
using System.Net.Http.Headers;
using System.Text.Json;

namespace HttpAccess;

public class RestContextUsuario : RestContext<Usuario> , IContextHttpUsuario
{
    public async Task<IEnumerable<Usuario>> GetAll(String filters)
    {
        // Agregar el token de acceso en la cabecera de autorización
        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());

        HttpResponseMessage response = await httpClient.GetAsync(apiUrl + filters);
        response.EnsureSuccessStatusCode();
        string responseBody = await response.Content.ReadAsStringAsync();
        JsonSerializerOptions options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,  // set camelCase       
            WriteIndented = true                                // write pretty json
        };
        // pass options to deserializer
        var usuarios = JsonSerializer.Deserialize<IEnumerable<Usuario>>(responseBody, options);
        return usuarios;
    }

    public RestContextUsuario(string apiUrl, IHttpContextAccessor httpContextAccessor) : base(apiUrl, httpContextAccessor)
    {
    }
}