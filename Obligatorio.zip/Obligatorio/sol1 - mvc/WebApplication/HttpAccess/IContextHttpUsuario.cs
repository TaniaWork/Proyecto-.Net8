﻿
using dto;

namespace HttpAccess
{
    public interface IContextHttpUsuario: IContextHttp<Usuario>
    {
        Task<IEnumerable<Usuario>> GetAll(string filters);
        
    }
}
