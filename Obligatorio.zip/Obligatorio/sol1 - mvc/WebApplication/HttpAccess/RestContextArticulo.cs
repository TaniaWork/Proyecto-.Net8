using dto;
using System.Net.Http.Headers;
using System.Text.Json;

namespace HttpAccess;

public class RestContextArticulo : RestContext<Articulo> , IContextHttpArticulo
{
    public async Task<IEnumerable<Articulo>> GetAll(String filters)
    {
        // Agregar el token de acceso en la cabecera de autorización
        httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", GetToken());

        HttpResponseMessage response = await httpClient.GetAsync(apiUrl + filters);
        response.EnsureSuccessStatusCode();
        string responseBody = await response.Content.ReadAsStringAsync();
        JsonSerializerOptions options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,  // set camelCase       
            WriteIndented = true                                // write pretty json
        };
        // pass options to deserializer
        var articulos = JsonSerializer.Deserialize<IEnumerable<Articulo>>(responseBody, options);
        return articulos;
    }

    public RestContextArticulo(string apiUrl, IHttpContextAccessor httpContextAccessor) : base(apiUrl, httpContextAccessor)
    {
    }
}