using dto;
using System.Net.Http.Headers;
using System.Text.Json;

namespace HttpAccess;

public class RestContextTipo : RestContext<Tipo>, IContextHttpTipo
{
    public async Task<TipoResponseDto> GetAll(String filters)
    {
        // Agregar el token de acceso en la cabecera de autorización
        httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", GetToken());

        HttpResponseMessage response = await httpClient.GetAsync(apiUrl + filters);
        response.EnsureSuccessStatusCode();
        string responseBody = await response.Content.ReadAsStringAsync();
        JsonSerializerOptions options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,  // set camelCase       
            WriteIndented = true                                // write pretty json
        };
        // pass options to deserializer
        var tipoResponseDto = JsonSerializer.Deserialize<TipoResponseDto>(responseBody, options);
        return tipoResponseDto;
    }

    public RestContextTipo(string apiUrl, IHttpContextAccessor httpContextAccessor) : base(apiUrl, httpContextAccessor)
    {
    }
}