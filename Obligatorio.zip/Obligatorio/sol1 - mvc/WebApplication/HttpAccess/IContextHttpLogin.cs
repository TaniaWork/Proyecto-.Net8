﻿using dto;

namespace HttpAccess
{
    public interface IContextHttpLogin
    {
       
        Task<LoginOutDto> Login(LoginDto entity);
       
    }
}
