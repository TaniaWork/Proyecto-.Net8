﻿
namespace dto
{


    public class Movimiento
    {

        public int Id { get; set; }

        public static int Contador = 1;
        public Articulo Articulo { get; set; }
        public DateTime Fecha { get; set; }
        public Usuario Usuario { get; set; }
        public int Unidades { get; set; }
        public string MailUsuario { get; set; }


        public int Tope = 100;
        public Tipo TipoMovimiento { get; set; }


        public Movimiento() { }

        public Movimiento(Articulo Articulo, Usuario Usuario, int unidades, Tipo TipoMovimiento)
        {
            Contador++;
            Id = Contador;
            Articulo = Articulo;
            Fecha = DateTime.Now;
            Usuario = Usuario;
            Unidades = Unidades;
            TipoMovimiento = TipoMovimiento;
            MailUsuario = this.Usuario.Email;
        }

        public void IsValid()
        {
        
        
        }

        public void Print() { }

    }
}

