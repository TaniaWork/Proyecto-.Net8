﻿
namespace dto
{


    public  class Articulo
    {
       

        
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Codigo { get; set; }
        public double Precio { get; set; }
        public int Stock { get; set; }


        public Articulo() { } // Constructor protegido
        public Articulo(string Nombre, string Descripcion, string Codigo, double Precio, int Stock)
        {
            Nombre = Nombre;
            Descripcion = Descripcion;
            Codigo = Codigo;
            Precio =  Precio;
            Stock = Stock;
           
        }

        public void IsValid()
        {
        
        
        }

        public void Print() { }

    }
}

