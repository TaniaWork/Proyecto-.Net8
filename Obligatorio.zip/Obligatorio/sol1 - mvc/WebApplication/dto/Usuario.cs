﻿

namespace dto
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Contrasena { get; set; }
        public string Rol {  get; set; }    

        public Usuario() { }
        public Usuario(string Email, string Nombre, string Apellido, string Contrasena, string Rol)
        {
            Email = Email;
            Nombre = Nombre;
            Apellido = Apellido;
            Contrasena = Contrasena;
            Rol = Rol;
        }

        public void IsValid()
        {


        }

        public void Print() { }

    }
}

