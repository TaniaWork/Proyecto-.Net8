﻿namespace dto
{
    public class Tipo
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;


        public Tipo(string nombre)
        {
            Nombre = nombre;
        }


        public Tipo()
        {
        }

        public void isValid() { }

    }
}