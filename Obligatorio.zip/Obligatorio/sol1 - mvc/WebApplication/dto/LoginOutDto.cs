﻿

namespace dto
{
    public class LoginOutDto
    {
        public string email { get; set; }
        public string nombre { get; set; }
        
        public string token { get; set; }
    
    }
}
