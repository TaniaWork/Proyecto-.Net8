namespace dto;

public class TipoResponseDto
{

    public int Count { get; set; }

    public IEnumerable<Tipo> Tipos { get; set; }


}