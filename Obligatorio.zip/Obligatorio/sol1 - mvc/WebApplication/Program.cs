
using HttpAccess;
using dto;
using Services;

namespace WebApplication1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            //en vez del DbContext de EF vamos a iyectar un RestContext hecho por nosotros 


            builder.Services.AddScoped(typeof(IContextHttpArticulo), provider => new RestContextArticulo(
                builder.Configuration.GetConnectionString("UrlArticulo"), new HttpContextAccessor()
            ));
            builder.Services.AddScoped(typeof(IContextHttpMovimiento), provider => new RestContextMovimiento(
                builder.Configuration.GetConnectionString("UrlMovimiento"), new HttpContextAccessor()
            ));
            builder.Services.AddScoped(typeof(IContextHttpTipo), provider => new RestContextTipo(
                builder.Configuration.GetConnectionString("UrlTipo"), new HttpContextAccessor()
            ));
            builder.Services.AddScoped(typeof(IContextHttpUsuario), provider => new RestContextUsuario(
               builder.Configuration.GetConnectionString("UrlUsuario"), new HttpContextAccessor()
           ));
            builder.Services.AddScoped(typeof(IContextHttpLogin), provider => new RestContextLogin(
               builder.Configuration.GetConnectionString("UrlLogin")
           ));

            builder.Services.AddScoped(typeof(IServiceMovimiento), typeof(ServiceMovimiento));
            builder.Services.AddScoped(typeof(IServiceTipo), typeof(ServiceTipo));

            builder.Services.AddScoped(typeof(IServiceArticulo), typeof(ServiceArticulo));
            builder.Services.AddScoped(typeof(IServiceUsuario), typeof(ServiceUsuario));
            builder.Services.AddScoped(typeof(IServiceLogin<LoginDto, LoginOutDto>), typeof(ServiceLogin));
            
            // Añade IHttpContextAccessor al contenedor de servicios
            builder.Services.AddHttpContextAccessor();
            
            
            // Add services to the container.
            builder.Services.AddControllersWithViews();

            builder.Services.AddDistributedMemoryCache();

            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromSeconds(1000);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");
            app.UseSession();
            app.Run();
        }
    }
}