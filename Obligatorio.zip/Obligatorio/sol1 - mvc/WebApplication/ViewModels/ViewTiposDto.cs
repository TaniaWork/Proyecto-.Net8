﻿using Domain.Exceptions;
using dto;
namespace WebApplication1.Models

{
    public class ViewTiposDto
    {
        public int Id { set; get; }
        public string Nombre { set; get; }

        public ViewTiposDto() { }
    }

   

}










 

     