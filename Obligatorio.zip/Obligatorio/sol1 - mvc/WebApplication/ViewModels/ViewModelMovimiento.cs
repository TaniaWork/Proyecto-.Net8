﻿using Domain.Exceptions;
using dto;
using System;

namespace WebApplication1.Models
{
    public class ViewModelMovimiento
    {
        public int Id { get; set; }

        public static int contador = 1;
        public Articulo Articulo { get; set; }
        public DateTime Fecha { get; set; }
        public Usuario Usuario { get; set; }
        public int Unidades { get; set; }
        public string MailUsuario { get; set; }


        public int Tope = 100;
        public Tipo TipoMovimiento { get; set; }



        public ViewModelMovimiento()
        { 
        
        }
        
        
        public ViewModelMovimiento(Movimiento movimientoDTO) 
        {
    
            this.Articulo = movimientoDTO.Articulo;
            this.Fecha = movimientoDTO.Fecha;
            this.Usuario = movimientoDTO.Usuario;
            this.Unidades = movimientoDTO.Unidades;
            this.Tope = movimientoDTO.Tope;
            this.TipoMovimiento = movimientoDTO.TipoMovimiento;
            this.MailUsuario = movimientoDTO.Usuario.Email;



        }

        public Movimiento ToMovimientoDto()
        {
            Movimiento movimientoDTO = new Movimiento();
            movimientoDTO.Id = this.Id;
            movimientoDTO.Articulo = this.Articulo;
            movimientoDTO.Fecha = this.Fecha;
            movimientoDTO.Usuario = this.Usuario;
            movimientoDTO.Unidades = this.Unidades;
            movimientoDTO.Tope = this.Tope;
            movimientoDTO.TipoMovimiento = this.TipoMovimiento;
            this.MailUsuario = movimientoDTO.Usuario.Email;


            return movimientoDTO;

        } 
            public void isValid()
    {
        if (this.Unidades < 0) //Las cantidades sean positivas.)
        {
            throw new MovimientoException("Las unidades deben ser valores positivos");
        }
        if (this.Unidades > Tope)//▪ No se pueden realizar movimientos que involucren más de un tope prefijado de
                                 //unidades. Ese tope no debe ser fijo, podría cambiar.) 
        {
            throw new MovimientoException("Las unidades no pueden superar el tope");
        }
        if (this.TipoMovimiento == null)//▪ El tipo de movimiento de stock sea uno de los existentes.) 
        {
            throw new MovimientoException("Debe existir el tipo de movimiento");
        }
        if (this.Usuario != null)//▪ El usuario exista, y se haya autenticado con rol encargado.
        {
            throw new MovimientoException("El Usuario debe existir");
        }
        if (this.Usuario.Rol == "Encargado")//▪ El usuario exista, y se haya autenticado con rol encargado.
        {
            throw new MovimientoException("El rol del usuario debe ser encargado");
        }
        if (this.Articulo == null)//▪El articulo debera existir
        {
            throw new MovimientoException("El articulo debe existir");
        }
        if (this.TipoMovimiento.Nombre == "Ingreso" || this.TipoMovimiento.Nombre == "Egreso")//▪ Solo se manejan ingresos y egresos.)
        {
            throw new MovimientoException("Los tipos de movimiento deben ser ingresos o egresos");
        }
    }

}
}
