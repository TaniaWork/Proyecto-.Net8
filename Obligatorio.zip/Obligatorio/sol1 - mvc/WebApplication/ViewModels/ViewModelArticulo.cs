﻿using Domain.Exceptions;
using dto;

namespace WebApplication1.Models
{
    public class ViewModelArticulo
    {

        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Codigo { get; set; }
        public double Precio { get; set; }
        public int Stock { get; set; }


        public ViewModelArticulo()
        { 
        
        }
        
        
        public ViewModelArticulo(Articulo articuloDTO) 
        {
            this.Nombre = articuloDTO.Nombre;
            this.Descripcion = articuloDTO.Descripcion;
            this.Codigo = articuloDTO.Codigo;
            this.Precio = articuloDTO.Precio;
            this.Stock = articuloDTO.Stock;

        }

        public Articulo ToArticuloDto()
        {
            Articulo articuloDTO = new Articulo();
            articuloDTO.Id = this.Id;
            articuloDTO.Nombre = this.Nombre;
            articuloDTO.Descripcion = this.Descripcion;
            articuloDTO.Codigo = this.Codigo;
            articuloDTO.Precio = this.Precio;
            articuloDTO.Stock = this.Stock;
            return articuloDTO;

        }




        public void IsValid()
        {
            if (this.Nombre == string.Empty)
            {
                throw new ArticuloException("El nombre del Articulo no puede ser vacío");
            }

            if (this.Stock <= 0)
            {
                throw new ArticuloException("El stock no puede ser negativo");
            }

        }
    }
}
