﻿using Microsoft.AspNetCore.Mvc;
using System.Web;
namespace WebApplication1.Models
{
    public class MyModel {
        public IFormFile ImageFile { get; set; }
        // otras propiedades del modelo
    }

}
