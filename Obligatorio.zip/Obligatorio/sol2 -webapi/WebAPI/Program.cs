
using System.Text;
using Domain.DataAccess;
using Domain.Dto;
using Domain.Models;
using Domain.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace WebAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            //inyecta el Contexto
            builder.Services.AddDbContext<DbContext, Contexto>(options =>
            {
                options.UseSqlServer(builder.Configuration.GetConnectionString("StringConnection"));
            });

            builder.Services.AddScoped(typeof(IRepositoryMovimiento<Movimiento>), typeof(RepositoryMovimiento));
            builder.Services.AddScoped(typeof(IServiceMovimiento<MovimientoDTO>), typeof(ServiceMovimiento));

            builder.Services.AddScoped(typeof(IRepositoryTipo<Tipo>), typeof(RepositoryTipo));
            builder.Services.AddScoped(typeof(IServiceTipo<TipoDTO>), typeof(ServiceTipo));

            builder.Services.AddScoped(typeof(IRepositoryUsuario<Usuario>), typeof(RepositoryUsuario));
            builder.Services.AddScoped(typeof(IServiceUsuario<UsuarioDTO>), typeof(ServiceUsuario));

            builder.Services.AddScoped(typeof(IRepositoryArticulo<Articulo>), typeof(RepositoryArticulo));
            builder.Services.AddScoped(typeof(IServiceArticulo<ArticuloDTO>), typeof(ServiceArticulo));

            builder.Services.AddScoped(typeof(IServiceLogin<LoginDto, LoginOutDto>), typeof(ServiceLogin));





            // Configurar la autenticaci�n JWT
            var claveSecreta = "clave_secreta_del_servidor_clave_secreta_del_servidor_clave_secreta_del_servidor_";
            var claveBytes = Encoding.ASCII.GetBytes(claveSecreta);

            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                options.RequireHttpsMetadata = false;
                options.SaveToken = true;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(claveBytes),
                    ValidateIssuer = false,
                    ValidateAudience = false
                };
            });

            // Configurar la autorizaci�n
            builder.Services.AddAuthorization(options =>
            {
                options.DefaultPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
            });

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();


            app.Run();
        }
    }
}