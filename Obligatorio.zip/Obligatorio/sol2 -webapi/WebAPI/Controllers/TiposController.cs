﻿using Domain.Dto;
using Domain.Exceptions;
using Domain.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]
    public class TiposController : ControllerBase
    {

        private IServiceTipo<TipoDTO> _service;
        public TiposController(IServiceTipo<TipoDTO> service)
        {
            _service = service;
        }

      //  [Authorize]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult Get([FromQuery] string? name="", int skip=0, int take=10)
        {
            TipoResponseDto tipos = _service.GetByName(name, skip, take);
            return Ok(tipos);
        }


        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Get(int id)
        {
            try
            {
                TipoDTO tipoDto = _service.GetById(id);
                return Ok(tipoDto);
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception.Message);
            }

        }


        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Delete(int id)
        {
            try
            {
                _service.Remove(id);
                return Ok("Eliminado con exito");
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception);
            }

        }


        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public IActionResult Put(int id, [FromBody] TipoDTO tipoDto)
        {
            try
            {
                _service.Update(id, tipoDto);
                return Ok("Modificado con exito");
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception);
            }
            catch (ElementoInvalidoException exception)
            {
                return BadRequest(exception.Message);
            }
            catch (ElementoEnConflictoException exception)
            {
                return Conflict(exception.Message);
            }
        }


        [HttpPost()]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public IActionResult Post([FromBody] TipoDTO tipoDto)
        {
            try
            {
                TipoDTO tipoDtoCreated = _service.Add(tipoDto);
                return Ok(tipoDtoCreated);
            }
            catch (YaExisteElementoException exception)
            {
                return StatusCode(StatusCodes.Status409Conflict, exception.Message);
            }
            catch (ElementoInvalidoException exception)
            {
                return BadRequest(exception.Message);
            }
        }
    }
}
