﻿ using Domain.Dto;
using Domain.Exceptions;
using Domain.Services;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {

        private IServiceUsuario<UsuarioDTO> _service;
        public UsuarioController(IServiceUsuario<UsuarioDTO> service)
        {
            _service = service;
        }


        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult Get()
        {
            IEnumerable<UsuarioDTO> Usuarios = _service.GetByEmail("");
            return Ok(Usuarios);
        }


        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Get(int id)
        {
            try
            {
                UsuarioDTO UsuarioDto = _service.GetById(id);
                return Ok(UsuarioDto);
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception.Message);
            }

        }


        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Delete(int id)
        {
            try
            {
                _service.Remove(id);
                return Ok("Eliminado con exito");
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception);
            }

        }


        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public IActionResult Put(int id, [FromBody] UsuarioDTO UsuarioDto)
        {
            try
            {
                _service.Update(id, UsuarioDto);
                return Ok("Modificado con exito");
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception);
            }
            catch (ElementoInvalidoException exception)
            {
                return BadRequest(exception.Message);
            }
            catch (ElementoEnConflictoException exception)
            {
                return Conflict(exception.Message);
            }
        }


        [HttpPost()]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public IActionResult Post([FromBody] UsuarioDTO UsuarioDto)
        {
            try
            {
                UsuarioDTO UsuarioDtoCreated = _service.Add(UsuarioDto);
                return Ok(UsuarioDtoCreated); 
            }
            catch (YaExisteElementoException exception)
            {
                return StatusCode(StatusCodes.Status409Conflict, exception.Message);
            }
            catch (ElementoInvalidoException exception)
            {
                return BadRequest(exception.Message);
            }
        }
    }
}
