﻿using Domain.Dto;
using Domain.Exceptions;
using Domain.Models;
using Domain.Services;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {

        

        private IServiceLogin<LoginDto, LoginOutDto> _service;
        public LoginController(IServiceLogin<LoginDto, LoginOutDto> service)
        {
            _service = service;
        }


        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult Post([FromBody] LoginDto loginDto)
        {
            try 
            { 
                LoginOutDto usuario = _service.Login(loginDto);
                return Ok(usuario);
            }catch(LoginException le) 
            {
                return Unauthorized(le.Message);
            }
        }


       
    }
}
