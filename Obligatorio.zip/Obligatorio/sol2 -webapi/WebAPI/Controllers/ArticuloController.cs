﻿using Domain.Dto;
using Domain.Exceptions;
using Domain.Services;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]
    public class ArticuloController : ControllerBase
    {

        private IServiceArticulo<ArticuloDTO> _service;
        public ArticuloController(IServiceArticulo<ArticuloDTO> service)
        {
            _service = service;
            service.GenerarArticulos();
        }


        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult Get()
        {
            IEnumerable<ArticuloDTO> Articulos = _service.GetByName("");
            return Ok(Articulos);
        }


        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Get(int id)
        {
            try
            {
                ArticuloDTO ArticuloDto = _service.GetById(id);
                return Ok(ArticuloDto);
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception.Message);
            }

        }


        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Delete(int id)
        {
            try
            {
                _service.Remove(id);
                return Ok("Eliminado con exito");
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception);
            }

        }


        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public IActionResult Put(int id, [FromBody] ArticuloDTO ArticuloDto)
        {
            try
            {
                _service.Update(id, ArticuloDto);
                return Ok("Modificado con exito");
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception);
            }
            catch (ElementoInvalidoException exception)
            {
                return BadRequest(exception.Message);
            }
            catch (ElementoEnConflictoException exception)
            {
                return Conflict(exception.Message);
            }
        }


        [HttpPost()]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public IActionResult Post([FromBody] ArticuloDTO ArticuloDto)
        {
            try
            {
                ArticuloDTO ArticuloDtoCreated = _service.Add(ArticuloDto);
                return Ok(ArticuloDtoCreated); 
            }
            catch (YaExisteElementoException exception)
            {
                return StatusCode(StatusCodes.Status409Conflict, exception.Message);
            }
            catch (ElementoInvalidoException exception)
            {
                return BadRequest(exception.Message);
            }
        }
    }
}
