﻿using Domain.DataAccess;
using Domain.Dto;
using Domain.Exceptions;
using Domain.Models;
using Domain.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace WebAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class MovimientoController : ControllerBase
    {

        private IServiceArticulo<ArticuloDTO> _serviceArticulo;
        private IServiceMovimiento<MovimientoDTO> _service;
        public MovimientoController(IServiceMovimiento<MovimientoDTO> service, IServiceArticulo<ArticuloDTO> serviceArticulo)
        {
            _service = service;
            _serviceArticulo = serviceArticulo;

        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]


        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]

        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Get(int id)
        {
            try
            {
                MovimientoDTO movimientoDto = _service.GetById(id);
                return Ok(movimientoDto);
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception.Message);
            }

        }
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Delete(int id)
        {
            try
            {
                _service.Remove(id);
                return Ok("Eliminado con exito");
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception);
            }

        }
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public IActionResult Put(int id, [FromBody] MovimientoDTO movimientoDto)
        {
            try
            {
                _service.Update(id, movimientoDto);
                return Ok("Modificado con exito");
            }
            catch (NoExisteElementoException exception)
            {
                return NotFound(exception);
            }
            catch (ElementoInvalidoException exception)
            {
                return BadRequest(exception.Message);
            }
            catch (ElementoEnConflictoException exception)
            {
                return Conflict(exception.Message);
            }
        }
        [HttpPost()]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public IActionResult Post([FromBody] MovimientoDTO movimientoDto)
        {
            try
            {
                MovimientoDTO movimientoDtoCreated = _service.Add(movimientoDto);
                return Ok(movimientoDtoCreated);
            }
            catch (YaExisteElementoException exception)
            {
                return StatusCode(StatusCodes.Status409Conflict, exception.Message);
            }
            catch (ElementoInvalidoException exception)
            {
                return BadRequest(exception.Message);
            }
        }

        //Consulta A
        [HttpGet("MovimientoConsulta1")]
        public ActionResult<IEnumerable<Movimiento>> GetMovimientosByArticuloAndTipo(
            [FromQuery] int articuloId,
            [FromQuery] string tipo,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10)
        {
            try
            {
                if (articuloId <= 0)
                {
                    return BadRequest("El ID del artículo debe ser un número positivo.");
                }

                if (string.IsNullOrEmpty(tipo))
                {
                    return BadRequest("El tipo de movimiento no puede estar vacío.");
                }

                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;

                var movimientosQuery = _service.GetAll()
                    .Where(m => m.Articulo != null && m.Articulo.Id == articuloId && m.TipoMovimiento != null && m.TipoMovimiento.Nombre == tipo);

                var totalRecords = movimientosQuery.Count();
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

                var movimientos = movimientosQuery
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

                if (!movimientos.Any())
                {
                    return NotFound("No se encontraron movimientos para los criterios especificados.");
                }

                var response = new
                {
                    TotalRecords = totalRecords,
                    TotalPages = totalPages,
                    PageNumber = pageNumber,
                    PageSize = pageSize,
                    Movimientos = movimientos
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                // Registra el error
                // Logger.LogError(ex, "Error en GetMovimientosByArticuloAndTipo");
                // Devuelve un error genérico
                return StatusCode(500, "Se produjo un error al procesar su solicitud.");
            }
        }

        //Consulta B
        [HttpGet("MovimientoConsulta2")]
        public ActionResult<IEnumerable<Articulo>> GetArticulosConMovimientosEnRangoFechas(
      [FromQuery] DateTime fechaInicio,
      [FromQuery] DateTime fechaFin,
      [FromQuery] int pageNumber = 1,
      [FromQuery] int pageSize = 10)
        {
            try
            {
                if (fechaInicio == default || fechaFin == default)
                {
                    return BadRequest("Las fechas de inicio y fin deben ser válidas.");
                }

                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;

                // Obtener los IDs de los artículos que tienen movimientos dentro del rango de fechas
                var articulosConMovimientos = _service.GetAll()
                    .Where(m => m.Fecha >= fechaInicio && m.Fecha <= fechaFin)
                    .Select(m => m.Articulo.Id)
                    .Distinct();

                // Obtener los artículos correspondientes a los IDs obtenidos
                var articulosQuery = _service.GetAllArticulos()
                    .Where(a => articulosConMovimientos.Contains(a.Id));

                var totalRecords = articulosQuery.Count();
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

                var articulos = articulosQuery
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

                if (!articulos.Any())
                {
                    return NotFound("No se encontraron artículos con movimientos en el rango de fechas especificado.");
                }

                var response = new
                {
                    TotalRecords = totalRecords,
                    TotalPages = totalPages,
                    PageNumber = pageNumber,
                    PageSize = pageSize,
                    Articulos = articulos
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                // Registra el error
                // Logger.LogError(ex, "Error en GetArticulosConMovimientosEnRangoFechas");
                // Devuelve un error genérico
                return StatusCode(500, "Se produjo un error al procesar su solicitud.");
            }
        }

        //consulta C
        [HttpGet("MovimientoConsulta3")]
        public ActionResult<IEnumerable<object>> GetResumenMovimientosPorAnioYTipo()
        {
            var resumenMovimientos = _service.GetAll()
                .GroupBy(m => new { Anio = m.Fecha.Year, Tipo = m.TipoMovimiento.Nombre })
                .Select(g => new
                {
                    Anio = g.Key.Anio,
                    Tipo = g.Key.Tipo,
                    Cantidad = g.Sum(m => m.Unidades)
                })
                .OrderBy(g => g.Anio)
                .ThenBy(g => g.Tipo)
                .ToList();

            if (resumenMovimientos.Count() == 0)
            {
                return NotFound("No se encontraron movimientos para generar el resumen.");
            }

            // Formatear la respuesta para mostrar el resumen de cantidades movidas por año y tipo
            var resumenFormateado = new List<object>();
            int? anioActual = null;
            foreach (var item in resumenMovimientos)
            {
                if (item.Anio != anioActual)
                {
                    if (anioActual != null)
                    {
                        resumenFormateado.Add(new { TotalAnio = resumenMovimientos.Where(r => r.Anio == anioActual).Sum(r => r.Cantidad) });
                    }
                    resumenFormateado.Add(new { Anio = item.Anio });
                    anioActual = item.Anio;
                }
                resumenFormateado.Add(new { Tipo = item.Tipo, Cantidad = item.Cantidad });
            }
            resumenFormateado.Add(new { TotalAnio = resumenMovimientos.Where(r => r.Anio == anioActual).Sum(r => r.Cantidad) });

            return Ok(resumenFormateado);
        }

    

}
}




