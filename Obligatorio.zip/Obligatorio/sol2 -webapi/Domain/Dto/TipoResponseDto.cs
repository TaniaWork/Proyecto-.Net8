﻿using System;
using Domain.Models;

namespace Domain.Dto
{
	public class TipoResponseDto
	{
		
		public int Count { get; set; }

		public IEnumerable<Tipo> Tipos { get; set; }

		
	}
}

