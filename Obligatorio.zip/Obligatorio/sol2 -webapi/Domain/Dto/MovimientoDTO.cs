﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Dto
{
    public class MovimientoDTO
    {
        public int Id { get; set; }

        public static int Contador = 1;
        public ArticuloDTO Articulo { get; set; }
        public DateTime Fecha { get; set; }
        public UsuarioDTO Usuario { get; set; }
        public string MailUsuario { get; set; }
        public int Unidades { get; set; }
        public TipoDTO TipoMovimiento { get; set; }

        public int Tope = 100;
        public MovimientoDTO() { }
        public MovimientoDTO(Articulo Articulo, Usuario Usuario, int Unidades, Tipo TipoMovimiento)
        {
            Contador++;
            Id = Contador;
            Articulo = Articulo;
            Fecha = DateTime.Now;
            Usuario = Usuario;
            Unidades = Unidades;
            TipoMovimiento = TipoMovimiento;
            MailUsuario = this.Usuario.Email;
        }


    }
}
