﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Dto
{
    public class TipoDTO
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

        public TipoDTO() { }    
        public TipoDTO(int Id, string nombre)
        {
            Id = Id;
            nombre = Nombre;
        }
    }
}
