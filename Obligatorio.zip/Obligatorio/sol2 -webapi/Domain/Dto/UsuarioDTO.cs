﻿using Domain.Exceptions;

namespace Domain.Dto
{
    public class UsuarioDTO
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Contrasena { get; set; }
        public string Rol { get; set; }

        public UsuarioDTO() { } 
        public void IsValid()
        {


            if (this.Nombre == string.Empty)
            {
                throw new UsuarioException("El nombre no puede ser vacío");
            }
            if (this.Apellido == string.Empty)
            {
                throw new UsuarioException("El apellido no puede ser vacío");
            }
            if (this.Rol == string.Empty)
            {
                throw new UsuarioException("El rol no puede ser vacío");
            }
        }

    }
}
