﻿using Domain.Exceptions;

namespace Domain.Dto
{
    public class ArticuloDTO
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Codigo { get; set; }
        public double Precio { get; set; }
        public int Stock { get; set; }

        public ArticuloDTO() { }    
        public void IsValid()
        {
            if (this.Nombre == string.Empty)
            {
                throw new ArticuloException("El nombre del Articulo no puede ser vacío");
            }

            if (this.Stock <= 0)
            {
                throw new ArticuloException("El stock no puede ser negativo");
            }

        }

    }
}
