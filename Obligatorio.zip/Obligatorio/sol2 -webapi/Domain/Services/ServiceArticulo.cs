﻿using Domain.DataAccess;
using Domain.Dto;
using Domain.Models;
using Bogus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Services
{
    public class ServiceArticulo : IServiceArticulo<ArticuloDTO>
    {

        private IRepositoryArticulo<Articulo> _repository;

        public ServiceArticulo(IRepositoryArticulo<Articulo> repository)
        {
            _repository = repository;
        }

        public ArticuloDTO Add(ArticuloDTO ArticuloDto)
        {

        Articulo articuloToCreate = new Articulo();

            articuloToCreate.Nombre = ArticuloDto.Nombre;
            articuloToCreate.Descripcion = ArticuloDto.Descripcion;
            articuloToCreate.Codigo = ArticuloDto.Codigo;
            articuloToCreate.Precio= ArticuloDto.Precio;
            articuloToCreate.Stock= ArticuloDto.Stock;
            articuloToCreate.IsValid();

            Articulo newArticulo = _repository.Add(articuloToCreate);
            ArticuloDTO newArticuloDto = new ArticuloDTO() { Id = newArticulo.Id, Nombre = newArticulo.Nombre };
            _repository.Save();
            return newArticuloDto;
        }

        public ArticuloDTO GetById(int id)
        {
            Articulo a = _repository.GetById(id);
            ArticuloDTO ArticuloDto = new ArticuloDTO()
            {
                Id = a.Id,
                Nombre = a.Nombre,
                Descripcion = a.Descripcion,
                Codigo = a.Codigo,
                Precio = a.Precio,
                Stock = a.Stock,
            };
            return ArticuloDto;
        }

        public IEnumerable<ArticuloDTO> GetByName(string name)
        {
            List<ArticuloDTO> ArticuloDto = new List<ArticuloDTO>();
            IEnumerable<Articulo> articulos = _repository.GetByName(name);
            foreach (Articulo a in articulos)
            {
                ArticuloDTO articuloDto = new ArticuloDTO()
                {
                    Id = a.Id,
                    Nombre = a.Nombre,
                    Descripcion = a.Descripcion,
                    Codigo =  a.Codigo,
                    Precio = a.Precio,
                    Stock= a.Stock,
                };
                ArticuloDto.Add(articuloDto);
            }
            return ArticuloDto;
        }

        public void Remove(int id)
        {
            Articulo articulo = _repository.GetById(id);
            _repository.Remove(articulo);
            _repository.Save();
        }


        public void Update(int id, ArticuloDTO ArticuloDto)
        {
            Articulo articulo = _repository.GetById(id);
            articulo.Nombre = ArticuloDto.Nombre;
            articulo.Descripcion = ArticuloDto.Descripcion;
            articulo.Codigo = ArticuloDto.Codigo;
            articulo.Precio = ArticuloDto.Precio;
            articulo.Stock = ArticuloDto.Stock;
            articulo.IsValid();
            _repository.Update(articulo);
            _repository.Save();
        }
        public IEnumerable<Articulo> GetAll()
        {
            IEnumerable<Articulo> lista = _repository.GetAll();
            return lista;
        }
        public void GenerarArticulos()
        {
            // Verificar si ya existen 80 artículos
            var existingArticulos = _repository.GetAll();
            if (existingArticulos.Count() >= 80)
            {
                return;
            }

            // Generar la cantidad necesaria de artículos para alcanzar 80
            int articulosToGenerate = 80 - existingArticulos.Count();
            var nuevosArticulos = new List<Articulo>();

            var faker = new Faker<Articulo>()
                .RuleFor(a => a.Nombre, f => f.Commerce.ProductName())
                .RuleFor(a => a.Descripcion, f => f.Lorem.Sentence())
                .RuleFor(a => a.Codigo, f => f.Random.Number(1000, 9999).ToString())
                .RuleFor(a => a.Precio, f => f.Random.Double(1, 100))
                .RuleFor(a => a.Stock, f => f.Random.Number(1, 50));

            for (int i = 0; i < articulosToGenerate; i++)
            {
                var articulo = faker.Generate();
                articulo.IsValid();
                nuevosArticulos.Add(articulo);
            }
        }

        }
}
