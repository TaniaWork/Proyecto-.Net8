﻿using Domain.Dto;
using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Services
{
    public interface IServiceMovimiento<T>
    {
        T Add(T dto);
        void Update(int id, T dto);
        void Remove(int id);
        T GetById(int Id);
        IEnumerable<Movimiento> GetAll();
        MovimientoDTO GetByName(int id, int skip, int take);
        IEnumerable<Articulo> GetAllArticulos();

    }
}
