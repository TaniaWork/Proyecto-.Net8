﻿using Domain.DataAccess;
using Domain.Dto;
using Domain.Exceptions;
using Domain.Models;
using System;
using System.Collections.Generic;

namespace Domain.Services
{
    public class ServiceTipo : IServiceTipo<TipoDTO>
    {

        private IRepositoryTipo<Tipo> _repository;
        public ServiceTipo(IRepositoryTipo<Tipo> repository) 
        {
            _repository = repository;

        }

        public TipoDTO Add(TipoDTO tipoDto)
        {
            Tipo tipoToCreate = new Tipo();
            tipoToCreate.Nombre = tipoDto.Nombre;
            Tipo newTipo = _repository.Add(tipoToCreate);
            _repository.Save();
            TipoDTO newTipoDto = new TipoDTO() { Id = newTipo.Id, Nombre = newTipo.Nombre };
            return newTipoDto;
        }

      

        public TipoDTO GetById(int id)
        {
            Tipo tipo = _repository.GetById(id);
            if (tipo == null) 
            {
                throw new NoExisteElementoException("No existe el tipo");
            }
            TipoDTO tipoDto = new TipoDTO()
            {
                Id = tipo.Id,
                Nombre = tipo.Nombre
            };
            return tipoDto;
        }

        public TipoResponseDto GetByName(string name, int skip, int take)
        {
            List<TipoDTO> tiposDto = new List<TipoDTO>();
            TipoResponseDto tipoResponse = _repository.GetByName(name, skip, take);
            
            return tipoResponse;
        }

        public void Remove(int id)
        {
            Tipo tipo = _repository.GetById(id);
            _repository.Remove(tipo);
            _repository.Save();
        }

        
        public void Update(int id, TipoDTO tipoDto)
        {
            Tipo tipo = _repository.GetById(id);
            tipo.Nombre = tipoDto.Nombre;
            _repository.Update(tipo);
            _repository.Save();
        }

        public void CrearTiposPrecargados()
        {
            var Ingreso = new Tipo
            {
                Id = 1,

                Nombre = "Ingreso",

            };
            var Egreso = new Tipo
            {
                Id = 2,

                Nombre = "Egreso",
            };
            _repository.Add(Ingreso);
            _repository.Add(Egreso);
        }
    }


}
