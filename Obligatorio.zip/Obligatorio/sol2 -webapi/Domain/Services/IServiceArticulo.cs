﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Services
{
    public interface IServiceArticulo<T>
    {
            T Add(T model);
            void Update(int id, T model);
            void Remove(int id);
            T GetById(int id);
            IEnumerable<T> GetByName(string name);
        IEnumerable<Articulo> GetAll();
        void GenerarArticulos();
    }
    }
