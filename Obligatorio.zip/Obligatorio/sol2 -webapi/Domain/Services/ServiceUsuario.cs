﻿using Domain.DataAccess;
using Domain.Dto;
using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Services
{
    public class ServiceUsuario : IServiceUsuario<UsuarioDTO>
    {

        private IRepositoryUsuario<Usuario> _repository;

        public ServiceUsuario(IRepositoryUsuario<Usuario> repository)
        {
            _repository = repository;
        }

        public UsuarioDTO Add(UsuarioDTO UsuarioDto)
        {

            Usuario UsuarioToCreate = new Usuario();

            UsuarioToCreate.Email = UsuarioDto.Email;
            UsuarioToCreate.Nombre = UsuarioDto.Nombre;
            UsuarioToCreate.Apellido = UsuarioDto.Apellido;
            UsuarioToCreate.Contrasena= UsuarioDto.Contrasena;
            UsuarioToCreate.Rol = UsuarioDto.Rol;

            UsuarioToCreate.IsValid();

            Usuario newUsuario = _repository.Add(UsuarioToCreate);
            UsuarioDTO newUsuarioDto = new UsuarioDTO() { Id = newUsuario.Id, Nombre = newUsuario.Nombre };
            _repository.Save();
            return newUsuarioDto;
        }

        public UsuarioDTO GetById(int id)
        {
            Usuario u = _repository.GetById(id);
            UsuarioDTO UsuarioDto = new UsuarioDTO()
            {
                Id = u.Id,
                Email = u.Email,
                Nombre = u.Nombre,
                Apellido= u.Apellido,
                Contrasena = u.Contrasena,
                Rol = u.Rol
            };
            return UsuarioDto;
        }

        public IEnumerable<UsuarioDTO> GetByEmail(string email)
        {
            List<UsuarioDTO> UsuarioDto = new List<UsuarioDTO>();
            IEnumerable<Usuario> usuarios = _repository.GetByEmail(email);
            foreach (Usuario u in usuarios)
            {
                UsuarioDTO usuarioDto = new UsuarioDTO()
                {
                    Id = u.Id,
                    Email = u.Email,
                    Nombre = u.Nombre,
                    Apellido =  u.Apellido,
                    Contrasena = u.Contrasena,
                    Rol = u.Rol 

                };
                UsuarioDto.Add(usuarioDto);
            }
            return UsuarioDto;
        }

        public void Remove(int id)
        {
            Usuario usuario = _repository.GetById(id);
            _repository.Remove(usuario);
            _repository.Save();
        }


        public void Update(int id, UsuarioDTO UsuarioDto)
        {
            Usuario usuario = _repository.GetById(id);
            usuario.Email = UsuarioDto.Email;
            usuario.Nombre = UsuarioDto.Nombre;
            usuario.Apellido = UsuarioDto.Apellido;
            usuario.Contrasena = UsuarioDto.Contrasena;
            usuario.Rol = UsuarioDto.Rol;
            usuario.IsValid();
            _repository.Update(usuario);
            _repository.Save();
        }

        public void CrearUsuarioDePrecarga()
        {
            var usuarioEncargado = new Usuario
            {
                Id = 1,
                Email = "encargado@example.com",
                Nombre = "Encargado",
                Apellido = "De Proyecto",
                Contrasena = "contrasenaSegura",
                Rol = "Encargado"
            };

            usuarioEncargado.IsValid();
            _repository.Add(usuarioEncargado);
        }
    }
}
