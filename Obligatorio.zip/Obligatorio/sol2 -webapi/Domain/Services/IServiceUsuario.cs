﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Services
{
    public interface IServiceUsuario<T>
    {
        T Add(T dto);
        void Update(int id, T dto);
        void Remove(int id);
        T GetById(int id);
        IEnumerable<T> GetByEmail(string email);
        void CrearUsuarioDePrecarga();
    }
}
