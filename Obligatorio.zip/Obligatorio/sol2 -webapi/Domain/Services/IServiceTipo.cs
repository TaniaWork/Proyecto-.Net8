﻿
using Domain.Dto;

namespace Domain.Services
{
    public interface IServiceTipo<T>
    {
        T Add(T dto);
        void Update(int id, T dto);
        void Remove(int id);
        T GetById(int id);
        TipoResponseDto GetByName(string name, int skip, int take);
        void CrearTiposPrecargados();

    }
}
