﻿using Domain.DataAccess;
using Domain.Dto;
using Domain.Exceptions;
using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Services
{
    public class ServiceMovimiento : IServiceMovimiento<MovimientoDTO>
    {
        private readonly IRepositoryMovimiento<Movimiento> _repository;
        private readonly IRepositoryTipo<Tipo> _repositoryTipoMovimiento;
        private readonly IRepositoryArticulo<Articulo> _repositoryArticulo;
        private readonly IRepositoryUsuario<Usuario> _repositoryUsuario;

        public ServiceMovimiento(IRepositoryMovimiento<Movimiento> repository,
         IRepositoryTipo<Tipo> repositoryTipo, IRepositoryArticulo<Articulo> repositoryArticulo, IRepositoryUsuario<Usuario> repositoryUsuario)
        {
            _repository = repository;
            _repositoryTipoMovimiento = repositoryTipo;
            _repositoryUsuario = repositoryUsuario;
            _repositoryArticulo = repositoryArticulo;
        }

  

        public MovimientoDTO Add(MovimientoDTO MovimientoDto)
        {
            Movimiento movimientoToCreate = new Movimiento();

            movimientoToCreate.Fecha = MovimientoDto.Fecha;
            movimientoToCreate.Usuario = _repositoryUsuario.GetById(MovimientoDto.Usuario.Id);
            movimientoToCreate.MailUsuario = MovimientoDto.Usuario.Email;
            movimientoToCreate.Articulo = _repositoryArticulo.GetById(MovimientoDto.Articulo.Id);
            movimientoToCreate.Unidades = MovimientoDto.Unidades;
            movimientoToCreate.TipoMovimiento = _repositoryTipoMovimiento.GetById(MovimientoDto.TipoMovimiento.Id); 
            movimientoToCreate.isValid();
            Movimiento newMovimiento = _repository.Add(movimientoToCreate);
            MovimientoDTO newMovimientoDto = new MovimientoDTO() { Id = newMovimiento.Id };
            _repository.Save();
            return newMovimientoDto;
        }

        public MovimientoDTO GetById(int Id)
        {
            if (Id == 0)
            {
                ++Id;
            }
            Movimiento m = _repository.GetById(Id);
            MovimientoDTO MovimientoDto = new MovimientoDTO()
            {
                Id = m.Id,
                Fecha = m.Fecha,
                Usuario = new UsuarioDTO()
                {
                    Id = m.Usuario.Id,
                    Nombre = m.Usuario.Nombre,
                    Apellido = m.Usuario.Apellido,
                    Email = m.Usuario.Email,
                    Rol = m.Usuario.Rol
                },
                Articulo = new ArticuloDTO()
                {
                    Id = m.Articulo.Id,
                    Nombre = m.Articulo.Nombre,
                    Descripcion = m.Articulo.Descripcion,
                    Codigo = m.Articulo.Codigo,
                    Precio = m.Articulo.Precio,
                    Stock = m.Articulo.Stock,
                },
                Unidades = m.Unidades,
                MailUsuario = m.Usuario.Email,
                TipoMovimiento = new TipoDTO()
                {
                    Id = m.TipoMovimiento.Id,
                    Nombre = m.TipoMovimiento.Nombre
                }

            };
            return MovimientoDto;
        }

        public MovimientoDTO GetByName(int id, int skip, int take)
        {
            List<MovimientoDTO> movimientoDto = new List<MovimientoDTO>();
            MovimientoDTO movimiento = _repository.GetByName(id, skip, take);
            return movimiento;
        }
      
        public void Remove(int id)
        {
            Movimiento movimiento = _repository.GetById(id);
            _repository.Remove(movimiento);
            _repository.Save();
        }
        public void Update(int id, MovimientoDTO MovimientoDto)
        {
            Movimiento movimiento = _repository.GetById(id);
            movimiento.Usuario = _repositoryUsuario.GetById(MovimientoDto.Usuario.Id);

            movimiento.Articulo = _repositoryArticulo.GetById(MovimientoDto.Articulo.Id);
            movimiento.Unidades = MovimientoDto.Unidades;
            movimiento.TipoMovimiento = _repositoryTipoMovimiento.GetById(MovimientoDto.TipoMovimiento.Id);
            movimiento.isValid();
            _repository.Update(movimiento);
            _repository.Save();
        }

        public IEnumerable<Articulo> GetAllArticulos()
        {
            IEnumerable<Articulo> lista = _repositoryArticulo.GetAll();
            return lista;
        }

        public IEnumerable<Movimiento> GetAll()
        {
            IEnumerable<Movimiento> lista = _repository.GetAll();
            return lista;
        }

    }
}

