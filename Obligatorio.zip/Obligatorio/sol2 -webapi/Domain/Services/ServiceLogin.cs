﻿using Domain.DataAccess;

using Domain.Exceptions;
using Domain.Models;

using System.Text;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using Domain.Dto;

namespace Domain.Services
{
    public class ServiceLogin : IServiceLogin<LoginDto, LoginOutDto>
    {

        private IRepositoryUsuario<Usuario> _repository;
        public ServiceLogin(IRepositoryUsuario<Usuario> repository)
        {
            _repository = repository;
        }

        public LoginOutDto Login(LoginDto loginDto)
        {
            
                Usuario usuario = _repository.GetBymail(loginDto.Email);
                if (usuario == null)
                {
                    throw new LoginException("No se encontró el usuario");
                }

                if (usuario.Contrasena.CompareTo(loginDto.Password) != 0)
                {
                    throw new LoginException("Credenciales inválidas");
                }

                //acá tenemos que firmar el token
                return new LoginOutDto
                {
                    Nombre = usuario.Nombre,
                    Email = loginDto.Email,
                    Token = GenerarTokenJwt(usuario.Email, "admin")
                };
            }

            private string GenerarTokenJwt(String name, String role)
            {
                // Clave secreta para firmar el token
                // esta clave la tenes que poner en el appsetings.json o en un lugar que no este en el codigo fuente para que no la vea todo el mundo
                //como es un ejemplo aca mostramos como es simplemente
                var claveSecreta = "clave_secreta_del_servidor_clave_secreta_del_servidor_clave_secreta_del_servidor_";

                // Crear los claims (información asociada al token) aca se puede poner si es admin o no por ejemplo
                var claims = new[]
                {
                new Claim(ClaimTypes.Name,name),
                new Claim(ClaimTypes.Role,role)// aca podes crear mas claims por ejemplo los rolees "Role", "Admin
            };

                // Crear la clave de seguridad usando la clave secreta
                var clave = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(claveSecreta));

                // Generar el token JWT
                var token = new JwtSecurityToken(
                    claims: claims,
                    expires: DateTime.UtcNow.AddMinutes(30),
                    signingCredentials: new SigningCredentials(clave, SecurityAlgorithms.HmacSha256)
                );

                // Convertir el token en una cadena
                String tokenString = new JwtSecurityTokenHandler().WriteToken(token);

                return tokenString;
            }

        }


    } 
