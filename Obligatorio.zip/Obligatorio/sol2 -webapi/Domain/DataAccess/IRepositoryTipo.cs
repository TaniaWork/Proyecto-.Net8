﻿using Domain.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataAccess
{
    public interface IRepositoryTipo <T>: IRepository<T>
    {
        TipoResponseDto GetByName(string name, int skip, int take);
        T GetById(int id);
    }
}
