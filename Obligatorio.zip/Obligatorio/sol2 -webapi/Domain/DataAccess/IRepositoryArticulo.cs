﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataAccess
{
    public interface IRepositoryArticulo<T>: IRepository<T>
    {
        IEnumerable<T> GetByName(string name);
        T GetById(int id);
        IEnumerable<Articulo> GetAll();
        void AddRange(IEnumerable<Articulo> articulos);

    }
}
