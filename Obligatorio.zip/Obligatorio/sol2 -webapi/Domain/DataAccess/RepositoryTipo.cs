﻿using Domain.Dto;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataAccess
{
    public class RepositoryTipo : GeneralRepository<Tipo>, IRepositoryTipo<Tipo>
    {

        public RepositoryTipo(DbContext context)
        {
            Context = context;
        }



        public Tipo GetById(int id)
        {
            return Context.Set<Tipo>().FirstOrDefault(Tipo => Tipo.Id == id);
        }

        public TipoResponseDto GetByName(string name, int skip, int take)
        {
            IEnumerable<Tipo> tipos = Context.Set<Tipo>()
                .Where(t => t.Nombre.Contains(name))
                .Skip(skip)
                .Take(take);

            int count = Context.Set<Tipo>()
                .Where(t => t.Nombre.Contains(name))
                .Count();

            TipoResponseDto tipoResponse = new TipoResponseDto()
            {
                Count = count,
                Tipos = tipos
            };

            return tipoResponse;

        }
    }
}
