﻿using Domain.Dto;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataAccess
{
    public class RepositoryMovimiento : GeneralRepository<Movimiento>, IRepositoryMovimiento<Movimiento>
    {
        public RepositoryMovimiento(DbContext context)
        {
            Context = context;
        }

        public Movimiento GetById(int id)
        {
            return Context.Set<Movimiento>()
                .Include(m => m.Usuario)
                .Include(m => m.Articulo)
                .Include(m => m.TipoMovimiento)
                .FirstOrDefault(Movimiento => Movimiento.Id == id);
        }


        public IEnumerable<Movimiento> GetAll()
        {
            return Context.Set<Movimiento>()
               .Include("Usuario")
                .Include("Articulo")
                .Include("TipoMovimiento");
        }
        public MovimientoDTO GetByName(int id, int skip, int take)
        {
            IEnumerable<Movimiento> tipos = Context.Set<Movimiento>()
                .Where(t => t.Id==(id))
                .Skip(skip)
                .Take(take);
            return new MovimientoDTO();
        }

    }
}
