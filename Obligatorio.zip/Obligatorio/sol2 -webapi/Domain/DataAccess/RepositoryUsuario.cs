﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataAccess
{
    public class RepositoryUsuario : GeneralRepository<Usuario>, IRepositoryUsuario<Usuario>
    {

        public RepositoryUsuario(DbContext context) 
        {
            Context = context;
        }

        public Usuario GetById(int id)
        {
            return Context.Set<Usuario>()
                .FirstOrDefault(usuario => usuario.Id == id);
        }
        public IEnumerable<Usuario> GetByEmail(string email)
        {
            return Context.Set<Usuario>()
                .Where(p => p.Email.Contains(email));
        }

        public Usuario GetBymail(string email)
        {
            return this.Context.Set<Usuario>()
             .FirstOrDefault(u => u.Email.CompareTo(email) == 0);
        }

    }
}


