﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataAccess
{
    public class RepositoryArticulo : GeneralRepository<Articulo>, IRepositoryArticulo<Articulo>
    {

        public RepositoryArticulo(DbContext context) 
        {
            Context = context;
        }

        private readonly List<Articulo> _articulos;
        public Articulo GetById(int id)
        {
            return Context.Set<Articulo>()
                .FirstOrDefault(articulo => articulo.Id == id);
        }

        public IEnumerable<Articulo> GetByName(string name)
        {
            return Context.Set<Articulo>()
                .Where(p => p.Nombre.Contains(name));
        }

        public RepositoryArticulo()
        {
            _articulos = new List<Articulo>();
        }

        public IEnumerable<Articulo> GetAll()
        {
            return Context.Set<Articulo>();
        }

        public void AddRange(IEnumerable<Articulo> articulos)
        {
            _articulos.AddRange(articulos);
        }
    }
}
