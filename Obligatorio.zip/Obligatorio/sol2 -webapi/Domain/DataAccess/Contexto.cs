﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;


namespace Domain.DataAccess
{
    public class Contexto : DbContext
    {
        public DbSet<Tipo> Tipos { get; set; }
        public DbSet<Articulo> Articulo { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Movimiento> Movimientos { get; set; }


        public Contexto(DbContextOptions options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Movimiento>()
                        .HasKey(m => m.Id);
            //probar
            modelBuilder.Entity<Movimiento>()
           .HasOne(c => c.Articulo)
           .WithMany();
            modelBuilder.Entity<Movimiento>()
              .HasOne(c => c.Usuario)
              .WithMany();
            base.OnModelCreating(modelBuilder);

          




            modelBuilder.Entity<Articulo>()
                     .HasKey(p => p.Id);

            modelBuilder.Entity<Usuario>()
                        .HasKey(u => u.Id);

            modelBuilder.Entity<Usuario>()
                         .HasIndex(p => p.Email)
                         .IsUnique();

            modelBuilder.Entity<Tipo>()
                       .HasKey(m => m.Id);
        }
    }

}
