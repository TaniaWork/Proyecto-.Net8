﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataAccess
{
    public class GeneralRepository<T> : IRepository<T> where T : class
    {
        protected DbContext Context { get; set; }

        public T Add(T entity)
        {
            Context.Set<T>().Add(entity);
            return entity;
        }
        public void Remove(T entity)
        {
            Context.Set<T>().Remove(entity);
        }
        public void Update(T entity)
        {
            Context.Entry(entity).State = EntityState.Modified;
        }     
        public void Save()
        {
            Context.SaveChanges();
        }
    }
}
