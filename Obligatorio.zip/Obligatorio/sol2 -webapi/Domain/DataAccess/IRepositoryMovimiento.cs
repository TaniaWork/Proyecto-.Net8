﻿using Domain.Dto;
using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataAccess
{
    public interface IRepositoryMovimiento<T> : IRepository<T>
    {
        T GetById(int id);
        IEnumerable<Movimiento> GetAll();
        MovimientoDTO GetByName(int id, int skip, int take);
    }
}
