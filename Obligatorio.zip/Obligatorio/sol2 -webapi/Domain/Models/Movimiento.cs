﻿using Domain.Dto;
using Domain.Exceptions;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models
{
    //Los movimientos de stock deberán tener un Id autonumérico, fecha y hora del movimiento,
    //artículo que se “mueve”, tipo de movimiento de stock, usuario que lo llevó a cabo, y la cantidad de
    //unidades que se mueven.
    //Estos movimientos no modifican el atributo de stock del artículo correspondiente a la parte 1,
    //por lo que se convierte en irrelevante.Podrá conservarlo o eliminarlo, según prefiera. Si no lo
    //elimina de la clase, deberá ignorarlo. 
    //El registro de este movimiento constará de:
    //El artículo al que se le aplica el movimiento
    //La fecha(incluyendo la hora) – Será la fecha del Sistema.
    //La cantidad(unidades)
    //El tipo de movimiento
    //El email del Usuario que lo llevó a cabo
    public class Movimiento
    {
        public int Id { get; set; }
        
        public static int Contador = 1;
        public Articulo Articulo { get; set; }
        public DateTime Fecha { get; set; }
        public Usuario Usuario { get; set; }
        public string MailUsuario { get; set; }
        public int Unidades { get; set;}
        public Tipo TipoMovimiento { get; set; }

        public int Tope = 100;
        public Movimiento() { }
        public Movimiento(Articulo Articulo, Usuario Usuario, int Unidades, Tipo TipoMovimiento)
        {
            Contador++;
            Id = Contador;
            Articulo = Articulo;
            Fecha = DateTime.Now;
            Usuario = Usuario;
            Unidades = Unidades;
            TipoMovimiento = TipoMovimiento;
            MailUsuario = this.Usuario.Email;
        }

        public void isValid()
        {
            if (this.Unidades<0) //Las cantidades sean positivas.)
            {
                throw new MovimientoException("Las unidades deben ser valores positivos");
            }
            if (this.Unidades>Tope)//▪ No se pueden realizar movimientos que involucren más de un tope prefijado de
//unidades. Ese tope no debe ser fijo, podría cambiar.) 
            {
                throw new MovimientoException("Las unidades no pueden superar el tope");
            }
            if (this.TipoMovimiento==null)//▪ El tipo de movimiento de stock sea uno de los existentes.) 
            {
                throw new MovimientoException("Debe existir el tipo de movimiento");
            }
            if (this.Usuario == null)//▪ El usuario exista, y se haya autenticado con rol encargado.
            {
                throw new MovimientoException("El Usuario debe existir");
            }
            if (this.Usuario.Rol != "Encargado")//▪ El usuario exista, y se haya autenticado con rol encargado.
            {
                throw new MovimientoException("El rol del usuario debe ser encargado");
             }
            if (this.Articulo == null)//▪El articulo debera existir
            {
                throw new MovimientoException("El articulo debe existir");
            }
            if (this.TipoMovimiento.Nombre != "Ingreso")//▪ Solo se manejan ingresos y egresos.)
            {
                throw new MovimientoException("Los tipos de movimiento deben ser ingresos o egresos");
            }
            //if (this.TipoMovimiento.Nombre != "Egreso")
            //{
            //    throw new MovimientoException("Los tipos de movimiento deben ser ingresos o egresos");
            //}
        }
    }
}

//▪ No se pueden realizar movimientos que involucren más de un tope prefijado de
//unidades. Ese tope no debe ser fijo, podría cambiar.
//Computación - Electrónica - Telecomunicaciones - Sistemas de Información
//▪ El tipo de movimiento de stock sea uno de los existentes.
//▪ Solo se manejan ingresos y egresos.



