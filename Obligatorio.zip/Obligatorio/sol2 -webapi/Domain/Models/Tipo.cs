﻿using Domain.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Domain.Models
{
    public class Tipo
    {


    //Los tipos de movimiento constan de un Id, un nombre único, (por ejemplo “Venta”, “Devolución”,
    //“Compra”, etc.).
    //En algunos casos el tipo de movimiento corresponde a una reducción del stock, y en otros casos a
    //un aumento.
    
        public int Id { get; set; }
        public string Nombre { get; set; }
       public Tipo() { }        
        public Tipo(int Id, string nombre) 
        {
            Id = Id;
            nombre = Nombre;
        }

        public void isValid() { }

    }
}
