﻿using Domain.Dto;
using Domain.Exceptions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Contrasena { get; set; }
        public string Rol { get; set; }

        public Usuario() { } // Constructor protegido
        public Usuario(int Id, string Email, string Nombre, string Apellido, string Contrasena, string Rol)
        {
            Id = Id;
            Email = Email;
            Nombre = Nombre;
            Apellido = Apellido;
            Contrasena = Contrasena;
            Rol = Rol;

        }


        public void IsValid()
        {
            if (this.Nombre == string.Empty)
            {
                throw new UsuarioException("El nombre no puede ser vacío");
            }
            if (this.Apellido == string.Empty)
            {
                throw new UsuarioException("El apellido no puede ser vacío");
            }

        }


        public void Print() { }

     
    } }




