﻿using Domain.Dto;
using Domain.Exceptions;
using System.Runtime.CompilerServices;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Domain.Models
{

    public  class Articulo
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Codigo { get; set; }
        public double Precio { get; set; }
        public int Stock { get; set; }


        public Articulo() { } // Constructor protegido
        public Articulo(string Nombre, string Descripcion, string Codigo, double Precio, int Stock)
        {
            Nombre = Nombre;
            Descripcion = Descripcion;
            Codigo = Codigo;
            Precio =  Precio;
            Stock = Stock;
           
        }

      
            public void IsValid()
            {
                if (this.Nombre == string.Empty)
                {
                    throw new ArticuloException("El nombre del Articulo no puede ser vacío");
                }

                if (this.Stock <= 0)
                {
                    throw new ArticuloException("El stock no puede ser negativo");
                }

            }

       
        public void Print() { }

        //public static implicit operator Articulo(ArticuloDTO v)
        //{
        //    throw new NotImplementedException();
        //}
    }
}

